﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;

namespace BegVCSharp_29_5_QueryXML
{
    class Program
    {
        static void Main(string[] args)
        {
            string xmlFileName = @"C:\BegVCSharp\Chapter29\Xml\NorthwindCustomerOrders.xml";
            XDocument customers = XDocument.Load(xmlFileName);

            Console.WriteLine("Elements in loaded document:");
            var queryResult = from c in customers.Elements()
                              select c.Name;
            foreach (var item in queryResult)
            {
                Console.WriteLine(item);
            }
            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine();

            // modifications described in chapter 29 follow - remove each set of comments in turn to compile and execute that example

            /*            
            Console.WriteLine("All descendants in document:");
            var queryResult =
                from c in customers.Descendants() 
                select c.Name;
            foreach (var item in queryResult)
            {
                Console.WriteLine(item);
            }
            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine();*/

            /*            
            Console.WriteLine("All distinct descendants in document:");
            var queryResult =
                from c in customers.Descendants()
                select c.Name;
            foreach (var item in queryResult.Distinct())
            {
                Console.WriteLine(item);
            }
            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine();*/

            /*            
            Console.WriteLine("Descendants named 'customer':");
            var queryResult =
                from c in customers.Descendants("customer") 
                select c.Name;
            foreach (var item in queryResult)
            {
                Console.WriteLine(item);
            }
            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine();*/

            /*            
            Console.WriteLine("Attributes of descendants named 'customer':");
            var queryResult =
                from c in customers.Descendants("customer").Attributes()
                select c.Name;

            foreach (var item in queryResult)
            {
                Console.WriteLine(item);
            }
            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine();*/

            /*            
            Console.WriteLine("Attributes named 'Company':");

            var queryResult =
                from c in customers.Descendants("customer").Attributes("Company")
                select c.Name;

            foreach (var item in queryResult)
            {
                Console.WriteLine(item);
            }
            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine();*/

            /*            
            Console.WriteLine("Values of customer attributes named 'Company':");
            var queryResults =
                from c in customers.Descendants("customer").Attributes("Company")
                select c;

            foreach (var item in queryResults)
            {
                Console.WriteLine(item);
            }
            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine(); */

            /*            
            Console.WriteLine("attributes named 'orderYear':");
            var queryResults =
                from c in customers.Descendants("order").Attributes("orderYear")
                select c;*/

            /*            
            foreach (var item in queryResults)
            {
                Console.WriteLine(item);
            }
            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine();*/

            /*            
            Console.WriteLine("Values of descendant attributes named 'orderYear':");
            var queryResults =
                from c in customers.Descendants("order").Attributes("orderYear")
                select c.Value;

            foreach (var item in queryResults)
            {
                Console.WriteLine(item);
            }
            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine();*/

            /*            
            var queryResults =
                from c in customers.Descendants("order").Attributes("orderYear")
                select c.Value;                      
            Console.WriteLine("Earliest year in which orders were placed: {0}", queryResults.Min());

            Console.Write("Press Enter/Return to continue:");
            Console.ReadLine();*/
 
        }
    }
}
