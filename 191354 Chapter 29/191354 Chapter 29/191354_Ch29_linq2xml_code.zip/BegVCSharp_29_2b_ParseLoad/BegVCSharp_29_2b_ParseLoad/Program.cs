﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;

namespace BegVCSharp_29_2b_ParseLoad
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement xdoc = XElement.Parse(@"
                    <customers>
                      <customer ID=""A"" City=""New York"" Region=""North America"">
                        <order Item=""Widget"" Price=""100"" />
                        <order Item=""Tire"" Price=""200"" />
                      </customer>
                      <customer ID=""B"" City=""Mumbai"" Region=""Asia"">
                        <order Item=""Oven"" Price=""501"" />
                      </customer>
                    </customers>
                    ");
            
            Console.WriteLine("Contents of xdoc:");
            Console.WriteLine(xdoc);

            Console.Write("Program finished, press Enter/Return to continue:");
            Console.ReadLine();

        }
    }
}