﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;

namespace BegVCSharp_29_1b_LINQToXMLElementText
{
    class Program
    {
        static void Main(string[] args)
        {
            XDocument xdoc = new XDocument(
                new XElement("customers",
                    new XElement("customer",
                        "AAAAAA",
                        new XAttribute("City", "New York"),
                        new XAttribute("Region", "North America")
                        ),
                    new XElement("customer",
                        "BBBBBB",
                        new XAttribute("City", "Mumbai"),
                        new XAttribute("Region", "Asia")
                    )
                )
            );

            Console.WriteLine(xdoc);

            Console.Write("Program finished, press Enter/Return to continue:");
            Console.ReadLine();

        }
    }
}