﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;

namespace BegVCSharp_29_4_XMLfromLINQtoSQL
{
    class Program
    {
        static void Main(string[] args)
        {
            NorthwindDataContext northWindDataContext = new NorthwindDataContext();

            XElement northwindCustomerOrders = new XElement("customers",
                                from c in northWindDataContext.Customers
                                select new XElement("customer",
                                    new XAttribute("ID", c.CustomerID),
                                    new XAttribute("City", c.City),
                                    new XAttribute("Company", c.CompanyName), //c.CompanyName
                                     from o in c.Orders
                                     select new XElement("order",
                                          new XAttribute("orderID", o.OrderID),
                                          new XAttribute("orderDay", o.OrderDate.Value.Day),
                                          new XAttribute("orderMonth", o.OrderDate.Value.Month), 
                                          new XAttribute("orderYear", o.OrderDate.Value.Year),
                                          new XAttribute("orderTotal",
                                              o.Order_Details.Sum(od => od.Quantity * od.UnitPrice))
                                        ) //end order
                                    
                                 ) // end customer
                               ); // end customers

            string xmlFileName = @"C:\BegVCSharp\Chapter29\Xml\NorthwindCustomerOrders.xml";

            northwindCustomerOrders.Save(xmlFileName);
            Console.WriteLine("Successfully saved Northwind customer orders to:");
            Console.WriteLine(xmlFileName);

            Console.WriteLine("Program finished, press Enter/Return to continue:");
            Console.ReadLine();
        }
    }
}
