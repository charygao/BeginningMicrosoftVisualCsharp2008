﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace TextureBrushExample3
{
  partial class Form1 : Form
  {
    private Image theImage;

    public Form1()
    {
      InitializeComponent();
      SetStyle(ControlStyles.Opaque, true);
      theImage = new Bitmap("tile.bmp");
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      Graphics g = e.Graphics;

      g.FillRectangle(Brushes.White, ClientRectangle);

      Brush tBrush = new TextureBrush(theImage, new Rectangle(0, 0,
                     theImage.Width, theImage.Height));
      Font trFont = new Font("Times New Roman", 32,
                    FontStyle.Bold | FontStyle.Italic);
      g.DrawString("Hello from Beginning Visual C#",
                   trFont, tBrush, ClientRectangle);
      tBrush.Dispose();
      trFont.Dispose();
    }
  }
}