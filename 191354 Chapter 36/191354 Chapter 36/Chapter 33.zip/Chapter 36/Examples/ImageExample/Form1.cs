﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace ImageExample
{
  partial class Form1 : Form
  {
    private Image theImage;

    public Form1()
    {
      InitializeComponent();
      SetStyle(ControlStyles.Opaque, true);
      theImage = new Bitmap("person.bmp");
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      Graphics g = e.Graphics;

      g.DrawImage(theImage, ClientRectangle);
    }
  }
}