﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

#endregion

namespace BrushExample
{
  partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      Graphics g = e.Graphics;

      g.FillRectangle(Brushes.White, ClientRectangle);

      g.FillRectangle(Brushes.Red, new Rectangle(10, 10, 50, 50));

      Brush linearGradientBrush = new LinearGradientBrush(
        new Rectangle(10, 60, 50, 50), Color.Blue, Color.White, 45);
      g.FillRectangle(linearGradientBrush, new Rectangle(10, 60, 50, 50));
      linearGradientBrush.Dispose();

      g.FillEllipse(Brushes.Aquamarine, new Rectangle(60, 20, 50, 30));

      g.FillPie(Brushes.Chartreuse, new Rectangle(60, 60, 50, 50), 90, 210);

      g.FillPolygon(Brushes.BlueViolet, new Point[] {
															  new Point(110, 10),
															  new Point(150, 10),
															  new Point(160, 40),
															  new Point(120, 20),
															  new Point(120, 60),
			});
    }
  }
}