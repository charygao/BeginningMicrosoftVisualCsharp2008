﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace TextureBrushExample1
{
  partial class Form1 : Form
  {
    private Image theImage;
    private Image smallImage;

    public Form1()
    {
      InitializeComponent();
      theImage = new Bitmap("Person.bmp");
      smallImage = new Bitmap(theImage,
                   new Size(theImage.Width / 2, theImage.Height / 2));
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      Graphics g = e.Graphics;

      g.FillRectangle(Brushes.White, ClientRectangle);

      Brush tBrush = new TextureBrush(smallImage, new Rectangle(0, 0,
                     smallImage.Width, smallImage.Height));
      g.FillEllipse(tBrush, ClientRectangle);
      tBrush.Dispose();
    }
  }
}